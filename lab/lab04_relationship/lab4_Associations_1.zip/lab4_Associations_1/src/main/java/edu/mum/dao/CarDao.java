package edu.mum.dao;

import edu.mum.domain.Car;

public interface CarDao extends GenericDao<Car> {
}
