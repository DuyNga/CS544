package edu.mum.cs544;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

@Aspect
@Component
public class LogAspect {
    private static Logger logger = LogManager.getLogger(LogAspect.class.getName());

    // indicate any return type
    //any method name
    //any parameters
//	@Before("execution(* *(..))")
//	public void logBefore(JoinPoint joinpoint) {
//		logger.warn("About to exec: " + joinpoint.getSignature().getName());
//	}

    @After("execution(* edu.mum.cs544.EmailSender.*(..))")
    public void logAfter(JoinPoint joinpoint) {
        Object[] args = joinpoint.getArgs();
//        logger.warn(String.format("method = %s address = %s message = %s outgoing mail server = %s",
//                joinpoint.getSignature().getName()
//                , args[0], args[1]), joinpoint.getTarget());

        logger.warn(String.format("method = %s address = %s message = %s",
                joinpoint.getSignature().getName()
                , args[0], args[1] + " outgoing mail server = " + joinpoint.getTarget()));
    }

    @Around("execution(* edu.mum.cs544.CustomerDAO.*(..))")
    public void around(ProceedingJoinPoint pjp) {
        String m = pjp.getSignature().getName();
//        System.out.println("Inside @Around: Before " + m);
//        Object ret = null;
        try {
            StopWatch sw = new StopWatch();
            sw.start(m);
            pjp.proceed();
            sw.stop();
            long totaltime = sw.getLastTaskTimeMillis();
            System.out.println(String.format("Time to execute save = %s ms", totaltime));
            // print the time to the console
//            ret = pjp.proceed();
//            ICustomerService customerService = (CustomerService) pjp.getTarget();
//            String value = customerService.getName();
//            System.out.println("value: " +value);
//            ret = value;
        } catch (Throwable e) {
            e.printStackTrace();
        }
//        System.out.println("Inside @Around: After " + m + " returned " + ret);
//        return ret;
    }

    //	@Before("execution(* *(..))")
//	public void logTargetBefore(JoinPoint joinpoint) {
//		logger.warn("About to exec a method on: " + joinpoint.getTarget());
//	}
//	@After("execution(* *(..))")
    public void logTargetAfter(JoinPoint joinpoint) {
        logger.warn("Just execed a method on: " + joinpoint.getTarget());
    }

}
